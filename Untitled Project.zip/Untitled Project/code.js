setScreen("home_screen");
onEvent("start_button", "click", function( ) {
  setScreen("zen_screen");
});
onEvent("home_button_1", "click", function( ) {
  setScreen("home_screen");
});
onEvent("settings_button_1", "click", function( ) {
  setScreen("settings_screen");
});
onEvent("tasks_button", "click", function( ) {
  setScreen("tasks_screen");
});
onEvent("start_button", "click", function( ) {
  setScreen("zen_screen");
});
onEvent("time_slider", "input", function( ) {
setText("time_label", getNumber("time_slider"));
});
onEvent("focus_button_1", "click", function( ) {
  setScreen("focus_screen");
});
onEvent("settings_button_2", "click", function( ) {
  setScreen("settings_screen");
});
onEvent("tasks_button_2", "click", function( ) {
  setScreen("tasks_screen");
});
onEvent("help_button_1", "click", function( ) {
  setScreen("help_screen");
});
onEvent("delete_button1", "click", function( ) {
  hideElement("checkbox1");
  hideElement("text_input1");
  onEvent("add_task_button", "click", function( ) {
    showElement("checkbox1");
    showElement("text_input1");
    setText("text_input1", "");
    setChecked("checkbox1", false);
  });
});
onEvent("delete_button2", "click", function( ) {
  hideElement("checkbox2");
  hideElement("text_input2");
  onEvent("add_task_button", "click", function( ) {
    showElement("checkbox2");
    showElement("text_input2");
    setText("text_input2", "");
    setChecked("checkbox2", false);
  });
});
onEvent("delete_button3", "click", function( ) {
  hideElement("checkbox3");
  hideElement("text_input3");
  onEvent("add_task_button", "click", function( ) {
    showElement("checkbox3");
    showElement("text_input3");
    setText("text_input3", "");
    setChecked("checkbox3", false);
  });
});
onEvent("delete_button4", "click", function( ) {
  hideElement("checkbox4");
  hideElement("text_input4");
  onEvent("add_task_button", "click", function( ) {
    showElement("checkbox4");
    showElement("text_input4");
    setText("text_input4", "");
    setChecked("checkbox4", false);
  });
});
onEvent("delete_button5", "click", function( ) {
  hideElement("checkbox5");
  hideElement("text_input5");
  onEvent("add_task_button", "click", function( ) {
    showElement("text_input5");
    showElement("checkbox5");
    setText("text_input5", "");
    setChecked("checkbox5", false);
  });
});
onEvent("home_button", "click", function( ) {
  setScreen("home_screen");
});
onEvent("home_button_help", "click", function( ) {
  setScreen("home_screen");
});
onEvent("settings_button_2", "click", function( ) {
  setScreen("settings_screen");
});
onEvent("focus_button_2", "click", function( ) {
  setScreen("focus_screen");
});
onEvent("home_button_2", "click", function( ) {
  setScreen("home_screen");
});
onEvent("volume_slider", "input", function( ) {
setText("volume_label2", getNumber("volume_slider"));
});
onEvent("help_button_2", "click", function( ) {
  setScreen("help_screen");
});
onEvent("end_early_button", "click", function( ) {
  setScreen("home_screen");
});
onEvent("start_button", "click", function( ) {
  setScreen("zen_screen");
  music_change();
});
onEvent("end_early_button", "click", function( ) {
  stopSound("assets/category_background/rain_thunderstorm_calm.mp3");
  stopSound("assets/lofi-lofi-song-401920.mp3");
  stopSound("assets/relax-397779.mp3");
});
onEvent("wallpaper_dropdown", "change", function( ) {
  if (getText("wallpaper_dropdown") == "Mountains") {
    setImageURL("image3", "https://pictures.altai-travel.com/1920x1040/mount-everest-aerial-view-himalayas-istock-3745.jpg");
  } else if ((getText("wallpaper_dropdown") == "Library")) {
    setImageURL("image3", "https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L3B4NzE4MzAzLWltYWdlLWt3dnhqNDhyLmpwZw.jpg");
  } else {
    
  }
});

function music_change() {
  if (getText("music_dropdown") == "Relax") {
    playSound("assets/relax-397779.mp3", true);
  } else if ((getText("music_dropdown") == "Lo-Fi")) {
    playSound("assets/lofi-lofi-song-401920.mp3", true);
  } else if ((getText("music_dropdown") == "Rain")) {
    playSound("assets/category_background/rain_thunderstorm_calm.mp3", true);
  } else {
    
  }
}
